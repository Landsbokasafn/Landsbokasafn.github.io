package is.landsbokasafn.deduplicator;

enum MatchingMethod {
	URL,
	DIGEST
}
